{{/* Metadata for aiida components */}}
{{- define "awattar.labels" }}
  generator: helm
  date: {{ now | htmlDate }}
  chart: {{ .Chart.Name }}
  version: {{ .Chart.Version }}
{{- end }}

{{/* Metadata for core components */}}
{{- define "awattar.core.labels" }}
labels:
  app: {{ .Release.Name }}-core
{{- include "awattar.labels" . }}
{{- end }}